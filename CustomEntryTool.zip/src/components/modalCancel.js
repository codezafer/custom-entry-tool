import React, { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';

function MyVerticallyCenteredModal(props) {
  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title id="contained-modal-title-vcenter">
          Exception!
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <p>
          Would you like to cancle this request?
        </p>
      </Modal.Body>
      <Modal.Footer>
        <Button onClick={props.onHide}>Yes</Button>
        <Button onClick={props.onHide}>No</Button>
        <Button onClick={props.onHide}>Next</Button>
      </Modal.Footer>
    </Modal>
  );
}

function PopUpCancel() {
  const [modalShow, setModalShow] = useState(false);

  return (
    <>
      <Button className='btn btn-dark rounded-lg' onClick={() => setModalShow(true)}>
        Cancel
      </Button>

      <MyVerticallyCenteredModal
        show={modalShow}
        onHide={() => setModalShow(false)}
      />
    </>
  );
}

export default PopUpCancel;