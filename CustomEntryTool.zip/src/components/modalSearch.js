import React, { useState } from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import { BsSearch } from 'react-icons/bs';
import { RxCross2 } from 'react-icons/rx';

function PopUpSearch() {
  const [open, setOpen] = useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <div>
      <span>
        <BsSearch size={20} className="icon-input" onClick={handleClickOpen} />
      </span>
      <Dialog open={open} onClose={handleClose}>
        <DialogContent  className="dialog-action">
          <TextField
            autoFocus
            margin="dense"
            id="name"
            label="Search"
            type="search"
            fullWidth
            variant="standard"
          /> 
          <button className='btn btn-primary'>search</button> 
          <span className='cross-icon' onClick={handleClose}><RxCross2/> </span>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default PopUpSearch;