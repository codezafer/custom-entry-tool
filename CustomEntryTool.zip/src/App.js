import React, { useState } from "react";
import "./App.css";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import { BsSearch } from "react-icons/bs";
import PopUpSubmit from "./components/modalSubmit";
import PopUpCancel from "./components/modalCancel";
import PopUpSearch from "./components/modalSearch";

function App() {
  // const [radioButton, setRadioButton] = useState(null);

  // const onClickAvailability = (e) => {
  //   if (e.target.checked && !radioButton) {
  //     setRadioButton({
  //       radioButton: true,
  //     });
  //   } else if (e.target.checked && radioButton) {
  //     setRadioButton({
  //       radioButton: false,
  //     });
  //   }

  const createData = (name, calories, fat, carbs, protein) => {
    return { name, calories, fat };
  };
  const rows = [
    createData("1", 159, 6.0, 24, 4.0),
    createData("2", 237, 9.0, 37, 4.3),
    createData("3", 262, 16.0, 24, 6.0),
  ];
  return (
    <div className="App">
      <div className="container-fluid">
        <div className="header">
          <button className="header-btn">View Email</button>
          <button className="header-btn">View Attachment</button>
        </div>

        <form>
          <div class="mb-3 row">
            <label class="col-sm-1 col-form-label">Exception</label>
            <div class="col-sm-5">
              <input type="text" class="form-control" />
            </div>
            <label class="col-sm-1 col-form-label">Exception Reason</label>
            <div class="col-sm-5">
              <input type="text" class="form-control" />
            </div>
          </div>

          <div class="mb-3 row">
            <label class="col-sm-1 col-form-label">
              Reason For Manual Task
            </label>
            <div class="col-sm-5">
              <input type="text" class="form-control" />
            </div>
            <div class="col-sm-5">
              <input
                type="text"
                class="form-control"
                placeholder="possible list of polaris numbers"
              />
            </div>
          </div>

          <div class="mb-3 row">
            <label class="col-sm-1 col-form-label">Reject Reason</label>
            <div class="col-sm-5">
              <select class="form-control3">
                <option>1</option>
                <option>2</option>
                <option>3</option>
              </select>
            </div>
            <label class="col-sm-1 col-form-label">Forward To Inquiries</label>
            <div class="col-sm-1">
              <input
                type="radio"
                className="radio-btn"
              // value={}
              // checked={radioButton}
              // onClick={onClickAvailability}
              // value="Click"
              />
              <label>Yes</label>
            </div>
            <div class="col-sm-1">
              <input type="radio" className="radio-btn" />
              <label>No</label>
            </div>
          </div>

          <div class="mb-3 row">
            <div class="col-sm-3">
              <label>Update Document Pages Decision</label>
            </div>
            <div class="col-sm-3">
              <input type="radio" className="radio-btn" />
              <label>No Changes in Document</label>
            </div>

            <div class="col-sm-3">
              <input type="radio" className="radio-btn" />
              <label>Remove Pages from Document</label>
            </div>
            <div class="col-sm-3">
              <input type="radio" className="radio-btn" />
              <label>Pages from Document to send</label>
            </div>
          </div>
        </form>

        <form>
          <div class="mb-3 row">
            <label class="col-sm-1 col-form-label">Order ID</label>
            <div class="col-sm-3">
              <input type="text" class="form-control" />
            </div>
            <label class="col-sm-1 col-form-label">
              Origin Zip/ Postal Code
            </label>
            <div class="col-sm-3">
              <input type="text" class="form-control" />
              <span>
                <input type="checkbox" className="radio-btn"></input>N/A
              </span>
            </div>
            <label class="col-sm-1 col-form-label">
              Destination Zip/ Postal Code
            </label>
            <div class="col-sm-3">
              <input type="text" class="form-control" />
              <span>
                <input type="checkbox" className="radio-btn"></input>N/A
              </span>
            </div>
          </div>

          <div class="mb-3 row">
            <label class="col-sm-1 col-form-label">Broker ID</label>
            <div class="col-sm-3">
              <div class="form-input">
                <PopUpSearch/>
                <input type="text" class="form-control" />
              </div>
            </div>
            <label class="col-sm-1 col-form-label">Broker Name</label>
            <div class="col-sm-3">
              <input type="text" class="form-control" />
            </div>
            <label class="col-sm-1 col-form-label">Broker Email</label>
            <div class="col-sm-3">
              <input type="text" class="form-control" />
            </div>
          </div>

          <div class="mb-3 row">
            <label class="col-sm-1 col-form-label">Total Amount</label>
            <div class="col-sm-3">
              <input type="text" class="form-control" />
              <span>
                <input type="checkbox" className="radio-btn"></input>N/A
              </span>
            </div>
            <label class="col-sm-1 col-form-label">Currency</label>
            <div class="col-sm-3">
              <input type="text" class="form-control" />
              <span>
                <input type="checkbox" className="radio-btn"></input>N/A
              </span>
            </div>
            <label class="col-sm-1 col-form-label">Description</label>
            <div class="col-sm-3">
              <input type="text" class="form-control" />
            </div>
          </div>
          <div class="col-sm-3">
            <TableContainer component={Paper} className="table-form">
              <Table size="small">
                <TableHead>
                  <TableRow className="table-row">
                    <TableCell align="center" className="table-cell">
                      HS Number
                    </TableCell>
                    <TableCell align="center" className="table-cell">
                      Item Description
                    </TableCell>
                    <TableCell align="center" className="table-cell">
                      Item Class
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows.map((row) => (
                    <TableRow
                      key={row.name}
                      sx={{
                        "&:last-child td, &:last-child th": { border: 0 },
                      }}
                    >
                      <TableCell
                        component="th"
                        scope="row"
                        align="center"
                        className="table-cell"
                      >
                        {row.name}
                      </TableCell>
                      <TableCell align="center" className="table-cell">
                        {row.calories}
                      </TableCell>
                      <TableCell align="center" className="table-cell">
                        {row.fat}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </div>
          <div class="mb-3 row">
            <label class="col-sm-1 col-form-label">HS Number</label>
            <div class="col-sm-2">
              <input type="text" class="form-control" />
            </div>
            <label class="col-sm-1 col-form-label">Item Description</label>
            <div class="col-sm-2">
              <input type="text" class="form-control" />
            </div>
            <label class="col-sm-1 col-form-label">Item Class </label>
            <div class="col-sm-2">
              <div class="form-input">
              <PopUpSearch/>
                <input type="text" class="form-control" />
              </div>
            </div>
            <div class="col-sm-2">
              <button class="btn-addItem">Add Item</button>
            </div>
          </div>
          <div className="btn-form2">
            <PopUpSubmit />
            <PopUpCancel />
          </div>
        </form>
      </div>
    </div>
  );
}

export default App;
